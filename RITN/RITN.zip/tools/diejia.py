
from PIL import Image
import os

# 文件夹路径
folder1 = './folder1'  # 第一个文件夹（透明度 30%）
folder2 = './folder2'  # 第二个文件夹（透明度 70%）
output_folder = './merged'

# 创建输出文件夹
os.makedirs(output_folder, exist_ok=True)

# 获取所有图片名（假设两文件夹图片名对应）
image_names = os.listdir(folder1)

for name in image_names:
    path1 = os.path.join(folder1, name)
    path2 = os.path.join(folder2, name)

    # 检查两个文件都存在
    if not os.path.exists(path2):
        print(f"跳过：{name}（第二个文件夹中不存在）")
        continue

    # 打开图像并转换为 RGBA（确保支持透明度）
    img1 = Image.open(path1).convert('RGBA')
    img2 = Image.open(path2).convert('RGBA')

    # 调整大小一致（如有差异）
    if img1.size != img2.size:
        img2 = img2.resize(img1.size)

    # 调整透明度
    img1 = img1.point(lambda p: p * 0.3)  # 30%
    img2 = img2.point(lambda p: p * 0.7)  # 70%

    # 合成（img1叠加在img2上）
    merged = Image.alpha_composite(img2, img1)

    # 保存结果
    save_path = os.path.join(output_folder, name.replace('.jpg', '.png'))
    merged.save(save_path)

    print(f"已生成：{save_path}")

print("✅ 所有图片已叠加完成！")