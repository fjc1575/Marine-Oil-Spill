ONNX weights can be downloaded from: https://pan.quark.cn/s/1ef40b00bfef.

The usage is consistent with the MMSegmentation codebase.

As this work is involved in an ongoing confidential project that has not yet been officially completed, the model architecture code cannot be released at this stage. Therefore, all trained weights have been converted to ONNX format, which can be directly used for inference via demo/demoonnx.py. However, the accuracy of the ONNX model is slightly lower than that of the original .pth weights. The project acceptance process is completed, the network architecture code and full model weights will be uploaded promptly.