import os
import cv2
import time
import numpy as np
import onnxruntime as ort

# 定义 Cityscapes 19 类的调色板 (RGB 格式)
# CITYSCAPES_PALETTE = np.array([
#     [128, 64, 128], [244, 35, 232], [70, 70, 70], [102, 102, 156],
#     [190, 153, 153], [153, 153, 153], [250, 170, 30], [220, 220, 0],
#     [107, 142, 35], [152, 251, 152], [70, 130, 180], [220, 20, 60],
#     [255, 0, 0], [0, 0, 142], [0, 0, 70], [0, 60, 100],
#     [0, 80, 100], [0, 0, 230], [119, 11, 32]
# ], dtype=np.uint8)
CITYSCAPES_PALETTE = np.array([
    [255, 255, 255], [0, 0, 0]
], dtype=np.uint8)

# 类别名称（仅供参考）
# CLASSES = ('road', 'sidewalk', 'building', 'wall', 'fence', 'pole',
#            'traffic light', 'traffic sign', 'vegetation', 'terrain', 'sky',
#            'person', 'rider', 'car', 'truck', 'bus', 'train', 'motorcycle',
#            'bicycle')
CLASSES =('oil', 'sea', )


def read_image_png(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"❌ 无法读取图像: {image_path}")
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def multi_class_segmentation(
        onnx_path,
        image_path,
        save_path="multi_class_result.png",
        block_size=1024,
        overlap=128,
        batch_size=4,
        device="cuda"
):
    """
    针对多分类（19类）ONNX 的分块推理
    """
    # 1. 初始化 Session
    providers = ["CUDAExecutionProvider", "CPUExecutionProvider"] if device == "cuda" else ["CPUExecutionProvider"]
    sess = ort.InferenceSession(onnx_path, providers=providers)
    input_name = sess.get_inputs()[0].name
    output_name = sess.get_outputs()[0].name

    # 2. 读取图像
    img = read_image_png(image_path)
    h, w = img.shape[:2]

    # 3. 预处理参数
    mean = np.array([123.675, 116.28, 103.53], dtype=np.float32)
    std = np.array([58.395, 57.12, 57.375], dtype=np.float32)

    # 准备结果容器
    # 注意：full_pred 存储的是类别 ID (uint8)
    full_pred = np.zeros((h, w), dtype=np.uint8)
    # 因为多分类通常采用投票或直接覆盖，简单起见我们使用中心覆盖法或分块平均
    # 这里我们采用简单的分块预测，最后统一处理

    # 4. 计算分块坐标
    stride = block_size - overlap
    coords = []
    for y in range(0, h, stride):
        for x in range(0, w, stride):
            y2 = min(y + block_size, h)
            x2 = min(x + block_size, w)
            y1 = max(0, y2 - block_size)
            x1 = max(0, x2 - block_size)
            coords.append((y1, y2, x1, x2))

    print(f"🚀 开始多分类推理，共 {len(coords)} 个分块...")

    # 5. 推理循环
    for i in range(0, len(coords), batch_size):
        batch_coords = coords[i: i + batch_size]
        batch_inputs = []

        for (y1, y2, x1, x2) in batch_coords:
            block = img[y1:y2, x1:x2]
            if block.shape[:2] != (block_size, block_size):
                block = cv2.resize(block, (block_size, block_size))

            block = (block.astype(np.float32) - mean) / std
            block = block.transpose(2, 0, 1)
            batch_inputs.append(block)

        batch_tensor = np.stack(batch_inputs, axis=0)

        # 执行推理得到 Logits: (B, 19, H, W)
        outputs = sess.run([output_name], {input_name: batch_tensor})[0]

        # 获取类别 ID: (B, H, W)
        batch_preds = np.argmax(outputs, axis=1).astype(np.uint8)

        # 贴回原图
        for pred, (y1, y2, x1, x2) in zip(batch_preds, batch_coords):
            actual_h, actual_w = y2 - y1, x2 - x1
            if pred.shape != (actual_h, actual_w):
                pred = cv2.resize(pred, (actual_w, actual_h), interpolation=cv2.INTER_NEAREST)
            full_pred[y1:y2, x1:x2] = pred

    # 6. 渲染颜色
    # 创建一个彩色空白图
    color_seg = np.zeros((h, w, 3), dtype=np.uint8)
    for label, color in enumerate(CITYSCAPES_PALETTE):
        color_seg[full_pred == label] = color

    # 7. 叠加原图显示 (Alpha 混合)
    # 将原图转回 BGR 方便 OpenCV 保存
    img_bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    color_seg_bgr = cv2.cvtColor(color_seg, cv2.COLOR_RGB2BGR)

    fusion = cv2.addWeighted(img_bgr, 0.5, color_seg_bgr, 0.5, 0)

    # 保存结果
    cv2.imwrite(save_path, fusion)
    cv2.imwrite("only_mask.png", color_seg_bgr)

    print(f"✅ 推理完成！结果已保存至: {save_path}")
    return full_pred


if __name__ == '__main__':
    # 填入你的路径
    MODEL_PATH = r"D:\1111\1111daima\RITN\run\RITNswo\SWOonnx\RITNsos1.onnx"
    IMAGE_PATH = r"D:\1111\1111daima\RITN\demo\01D6_1_2.png"

    multi_class_segmentation(
        onnx_path=MODEL_PATH,
        image_path=IMAGE_PATH,
        block_size=256,
        batch_size=1,
        device="cuda"
    )